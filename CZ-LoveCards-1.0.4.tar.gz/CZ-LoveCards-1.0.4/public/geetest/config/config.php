<?php
define("CAPTCHA_ID", "5149e1557f026241f56a72b8a59fedfb");
define("PRIVATE_KEY", "f8862257aabf62e41c279f9d7697fa60");
