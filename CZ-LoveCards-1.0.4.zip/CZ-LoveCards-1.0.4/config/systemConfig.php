<?php
//系统基本信息
define('SYSTEM_TITTLE','LoveCards1.0.4开源版');//tittle标签
define('SYSTEM_KEYWORDS','LoveCards1.0.4开源版');//meat标签keyworld属性
define('SYSTEM_DESCRIPTION','LoveCards1.0.4开源版');//meat标签description属性

define('SYSTEM_COPYRIGHT','LoveCards表白墙Made by 吃纸怪 Copyright © 2019-2021 FatDa');//站点copyright版权
define('SYSTEM_FRIENDS','<a href=\"//fatda.cn\">FatDa</a><a href=\"//chizg.cn\">吃纸怪</a>');//站点友情链接版权

define('SYSTEM_NOTICE','LoveCards1.0.4开源版');//站点友情链接版权
define('SYSTEM_NOTICE1','LoveCards表白墙Made by 吃纸怪 Copyright © 2019-2021 FatDa');//站点友情链接版权

define('SYSTEM_URL','127.0.0.1');//网站URL
define('SYSTEM_KEY','QOJW45XILvpxibznqUY43Gr3UEEceqAp0eSd04bVvXjN/9OgB87bZ6rAwYlBlKxYBDMfBkvPnwbmKIXAafFP0m0a1vT7Jlq9GGE9R1xi83xNCkj3GD66sLXfG0NsuF8qZ5d3d1lOXOxG8IN/jJmY0SzwymR4b/T1WfdsGL9epWU=');//当前版本密钥

define('SYSTEM_RULE','/(黄)|(赌)|(毒)|(Q币)|(电影网站)|(聚合影视APP)|(视频聊天)|(直播)|(P2P)|(私彩)|(要饭网)|(各种盗号钓鱼软件)|(游戏外挂辅助)|(短信)|(电话轰炸机)|(以及话费充值)|(直播盒子)|(百度云盘)|(王者荣耀CDK)|(以及各种抽奖)|(一元夺宝)|(股票)|(金融)|(理财)|(彩票福利)|(洗钱)|(信用卡套现)|(花呗套现)/');//正则匹配
define('SYSTEM_DELET','true');//删除开关