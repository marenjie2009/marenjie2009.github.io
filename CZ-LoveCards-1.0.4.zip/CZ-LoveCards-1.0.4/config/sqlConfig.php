<?php
//数据库信息
define('DB_HOST','localhost');//Mysql数据库服务器
define('DB_USER','lovecards');//Mysql数据库用户名
define('DB_PASSWORD','lovecards');//Mysql数据库密码
define('DB_DATABASE','lovecards');//Mysql数据库名
define('DB_PORT','3306');//Mysql数据库端口
define('SYSTEM_VERSION', '1.0.4');//当前系统版本号